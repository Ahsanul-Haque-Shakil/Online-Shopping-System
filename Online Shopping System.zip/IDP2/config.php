<?php

$conn = mysqli_connect('localhost','root','','bd_online_shop') or die('connection failed');

?>