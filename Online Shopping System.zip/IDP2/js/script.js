let userBox = document.querySelector('.header .header-2 .user-box');

document.querySelector('#user-btn').onclick = () =>{
   userBox.classList.toggle('active');
   navbar.classList.remove('active');
}

let navbar = document.querySelector('.header .header-2 .navbar');

document.querySelector('#menu-btn').onclick = () =>{
   navbar.classList.toggle('active');
   userBox.classList.remove('active');
}

window.onscroll = () =>{
   userBox.classList.remove('active');
   navbar.classList.remove('active');

   if(window.scrollY > 60){
      document.querySelector('.header .header-2').classList.add('active');
   }else{
      document.querySelector('.header .header-2').classList.remove('active');
   }
}


// Email validation function
function validateEmail(email) {
   // Regular expression pattern for email validation
   var pattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
   return pattern.test(email);
 }
 
 // Password validation function
 function validatePassword(password) {
   // Regular expression pattern for password validation
   var pattern = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*]).{8,}$/;
   return pattern.test(password);
 }
 
 // Function to enable or disable the submit button based on validation results
 function enableSubmitButton() {
   var fname = document.getElementsByName('fname')[0].value;
   var lname = document.getElementsByName('lname')[0].value;
   var email = document.getElementsByName('email')[0].value;
   var password = document.getElementsByName('password')[0].value;
   var cpassword = document.getElementsByName('cpassword')[0].value;
   var privacyPolicy = document.getElementById('Privacy_Policy').checked;
   var submitButton = document.getElementById('btn');
 
   // Check if all fields are valid
   if (
     fname.length > 0 &&
     lname.length > 0 &&
     validateEmail(email) &&
     validatePassword(password) &&
     password === cpassword &&
     privacyPolicy
   ) {
     submitButton.disabled = false;
   } else {
     submitButton.disabled = true;
   }
 }
 
 // Add event listeners for input fields
 document.getElementsByName('fname')[0].addEventListener('input', enableSubmitButton);
 document.getElementsByName('lname')[0].addEventListener('input', enableSubmitButton);
 document.getElementsByName('email')[0].addEventListener('input', enableSubmitButton);
 document.getElementsByName('password')[0].addEventListener('input', enableSubmitButton);
 document.getElementsByName('cpassword')[0].addEventListener('input', enableSubmitButton);
 document.getElementById('Privacy_Policy').addEventListener('click', enableSubmitButton);
 