<?php
include 'config.php';
session_start();

$user_id = $_SESSION['user_id'];

if(!isset($user_id)){
   header('location:login.php');
}

// Retrieve user information
$user_query = mysqli_query($conn, "SELECT * FROM `users` WHERE id = '$user_id'");
$user_info = mysqli_fetch_assoc($user_query);

?>

<!DOCTYPE html>
<html lang="en">

<!-- ... (head and other HTML code) ... -->

<body>

<?php include 'header.php'; ?>

<div class="heading">
   <h1 style="text-align: center;">Your Profile</h1>
   <div>
      <p> <br></p>
   </div>
</div>

<section class="user-profile">

   <h1 style="text-align: center;">User Information</h1>

   <div class="box-container" style="text-align: center;">
      <div class="box">
         <p>First Name: <span><?php echo $user_info['fname']; ?></span></p>
         <p>Last Name: <span><?php echo $user_info['lname']; ?></span></p>
         <p>Email: <span><?php echo $user_info['email']; ?></span></p>
         <!-- Add any other user information you want to display -->
      </div>
   </div>

</section>
<br>
<br>
<br>

<section class="placed-orders">
   <h1 style="text-align: center;">Placed Orders</h1>

   <?php
   // Retrieve orders for the user
   $order_query = mysqli_query($conn, "SELECT * FROM `orders` WHERE user_id = '$user_id'") or die('query failed');
   if (mysqli_num_rows($order_query) > 0) {
      while ($fetch_orders = mysqli_fetch_assoc($order_query)) {
   ?>
         <div class="box-container">
            <div class="box">
               <p>Order ID: <span><?php echo $fetch_orders['id']; ?></span></p>
               <p>Name: <span><?php echo $fetch_orders['name']; ?></span></p>
               <p>Number: <span><?php echo $fetch_orders['number']; ?></span></p>
               <p>Email: <span><?php echo $fetch_orders['email']; ?></span></p>
               <p>Method: <span><?php echo $fetch_orders['method']; ?></span></p>
               <p>Address: <span><?php echo $fetch_orders['address']; ?></span></p>
               <p>Total Products: <span><?php echo $fetch_orders['total_products']; ?></span></p>
               <p>Total Price: <span><?php echo $fetch_orders['total_price']; ?></span></p>
               <p>Placed On: <span><?php echo $fetch_orders['placed_on']; ?></span></p>
               <p>Payment Status: <span><?php echo $fetch_orders['payment_status']; ?></span></p>
               <!-- Display other order details as needed -->
            </div>
         </div>
   <?php
      }
   } else {
      echo '<p class="empty">No orders placed yet!</p>';
   }
   ?>

</section>

<?php include 'footer.php'; ?>

<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>
